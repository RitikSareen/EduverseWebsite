import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AssignmentChannelRoutingModule } from './assignment-channel-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    AssignmentChannelRoutingModule
  ]
})
export class AssignmentChannelModule { }
