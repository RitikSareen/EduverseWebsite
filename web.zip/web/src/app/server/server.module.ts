import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServerRoutingModule } from './server-routing.module';
import { ServerSidebarComponent } from './server-sidebar/server-sidebar.component';


@NgModule({
  declarations: [
    ServerSidebarComponent
  ],
  imports: [
    CommonModule,
    ServerRoutingModule
  ]
})
export class ServerModule { }
